var mongoose = require('mongoose');
const path = require('path')

//MongoDB connection
mongoose.connect("mongodb://127.0.0.1:27017/AllTake2");

const express = require("express");4

const app = express();

//const upload = multer({dest : 'uploads/'})

var userRoute = require('./routes/userRoute');

// Web Socket Creation 
const http = require("http");
const {Server} = require("socket.io");
const { Socket } = require("dgram");

const socketIo = require('socket.io');

// const multer = require('multer');

// app.post('/upload', upload.single('file'),(req,res)=>{
//     if(!req.file){
//         return res.status(400).send('No file uploaded');
//     }

//     res.send('file uploaded succesfully');
// });



const server = http.createServer(app);

// Create a new instance of a Socket.IO server, attached to the HTTP server
const io = socketIo(server);

//Web Socket Connection 
io.on('connection', (client) => {
    console.log('new user has connected ', Socket.id);
})

app.use(express.static(path.resolve("./public")));

// app.get("/",(req, res)=> {
//     return res.sendFile('./public/index.html');
// });

// Use the user route for any requests to the root path
app.use('/', userRoute);



// Start the server and listen on port 
const PORT = process.env.PORT || 8002;
app.listen(PORT, function(){
    console.log('app is running');
})