// Import the User model from the ../model/User file
var User = require('../model/User');

// Import the csvtojson library for converting CSV files to JSON objects
var csv = require('csvtojson');


// const importUser = async(req , res )=>{
// Define an asynchronous function named createConnection that takes a request and response as parameters
   const createConnection = async(req , res )=>{
    try{
       // Initialize an empty array to store user data
        var userData = [];
       // Use the csvtojson library to read and convert the CSV file located at req.file.path
        csv().fromFile(req.file.path)
        .then(async(response)=>{
            //console.log(response);

            // Iterate over each record in the response array

            for(var x=0 ; x<response.length; x++){
              
                // Push an object representing a user into the userData array
                userData.push({
                    FirstName : response[x].FirstName,
                    LastName :  response[x].LastName,
                    Email   :   response[x].Email,
                    JobTitle :  response[x].JobTitle,



                });

            }
// Insert all user data into the User collection in the database
            await User.insertMany(userData);

        })

        // Send a success response back to the client
        res.send({success: true , status : 200  , msg : 'CSV IMPORTED'})
        
    }catch (error){
 
        // If an error occurs, send an error response back to the client
        res.send({success: false , status : 400  , msg : error.message});


    }
}

// Export the createConnection function so it can be used in other files

module.exports={
  createConnection
}