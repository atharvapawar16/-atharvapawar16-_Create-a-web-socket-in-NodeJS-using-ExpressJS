const express = require("express");4

const user = express();


const multer = require('multer');

const path = require('path');

const bodyParser = require('body-parser');

// Use body-parser middleware to parse URL-encoded data with the querystring library
user.use(bodyParser.urlencoded({extended:true}));

// Serve static files from the 'public' directory
user.use(express.static(path.resolve(__dirname , 'public')));


// Configure storage settings for multer

var storage = multer.diskStorage({
    // Set the destination directory for uploaded files
    destination : (req, file , cb)=>{
       cb(null, './public/uploads')
    },

    filename : (req , file , cb )=>{
        cb(null,file.originalname)
    }
});

// Create a multer instance with the specified storage settings
var upload = multer({storage: storage});

const userController = require('../controller/userController');

// Define a POST route '/createConnection' that handles file uploads using multer and calls createConnection method from userController
user.post('/createConnection', upload.single('file'),userController.createConnection);

module.exports = user;