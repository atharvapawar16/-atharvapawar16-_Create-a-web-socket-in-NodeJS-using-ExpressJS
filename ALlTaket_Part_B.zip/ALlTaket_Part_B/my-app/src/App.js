
import { useState } from 'react';
import { Container, Form, Button, ProgressBar, Alert, Table } from 'react-bootstrap';
import Papa from 'papaparse';
import './App.css';
import axios from 'axios';

function App() {

  //use usestate to create  variable data 

  const [data , setData] = useState([]);
  const [error , setError] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [success, setSuccess] = useState(false);
  const [csvData, setCsvData] = useState([]);



  //function handle file upload eventobject = e (automatically pass on eventlistner)
  const handleFileUpload = (e) =>{

    // file list object conatin information about the file 
    const file = e.target.files[0];

    Papa.parse(file , {
      header: true ,
      complete :(results)=>{
        setData(results.data);
      },
    });
  };


  //If the file is any other than CSV format then display validation error.
  const validateFile= (file) =>{
    const validExtensions = ['csv'];
    //This line extracts the file extension from the selected file's name. 
    const fileExtension = file.name.split('.').pop().toLowerCase();
    return validExtensions.includes(fileExtension);
  };


  

  const handleSubmit = async (file) => {
    file.preventDefault ();

    if(!file){
      setError('Please select a file to upload');
      return ;
    }
    if(!validateFile(file)){
      setError('Only CSV files are allowed to upload ');
      return ;
    }


    //Using progress bar show real-time progress of file upload.
    const formData = new formData();

    formData.append('file', file);

    try {


     //call api  using axios library.

      await axios.post('/upload', formData,{
        headers :{
          'ContentType': 'multipart/form-data',
        },

        onUploadProgress :(ProgressEvent)=>{
          const progress = Math.round((ProgressEvent.loaded * 100)/ ProgressEvent.total);
          setUploadProgress(progress);
        },
      });

      setSuccess(true);
      
    } catch (error) {

      setError('Error in uploading File');
      
    }

    
  }




  
  return (
    <div className="App">
      <input type="file" accept='.csv' onChange={handleFileUpload} /> 
     {data.length ? (
      <table className='table'>
        <thead>
          <tr>
            <th>FirstName</th>
            <th>LastName</th>
            <th>Email</th>
            <th>JobTitle</th>
          </tr>
        </thead>
        <tbody>
           {/* // map call on data array */}
          {data.map((row , index)=>(
             // JSX resturned for each element 

             <tr key ={index}>

              <td>{row.FirstName}</td>
              <td>{row.LastName}</td>
              <td>{row.Email}</td>
              <td>{row.JobTitle}</td>

             </tr>

          ))}
        </tbody>
      </table>
     ) : null}
    </div>
  );
}

export default App;
